//contenido, contexto, estado general de la aplicación

import React from "react";

let Context = React.createContext();

export default Context;