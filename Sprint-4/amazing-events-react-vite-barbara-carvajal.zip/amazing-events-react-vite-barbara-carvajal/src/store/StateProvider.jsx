import { useState } from "react";
import StateContext from "./StateContext";

function StateProvider({ children }) {
  const [eventos, setEventos] = useState([]);
  const [evento, setEvento] = useState({
    _id: 0,
    image: "",
    name: "",
    description: "",
    category: "",
    place: "",
    capacity: 0,
    assistance: 0,
    estimate: 0,
    price: 0,
  });

  const state = {
    eventos: eventos,
    evento: evento,
    setEvento: setEvento, // Agrega la función setEvento al estado
  };

  return (
    <StateContext.Provider value={state}>
      {children}
    </StateContext.Provider>
  );
}

export default StateProvider;
